package com.infofutsal.infofutsal.adapter;

/**
 * Created by Ritky on 10/14/2017.
 */

public class GridAdapter {
}
